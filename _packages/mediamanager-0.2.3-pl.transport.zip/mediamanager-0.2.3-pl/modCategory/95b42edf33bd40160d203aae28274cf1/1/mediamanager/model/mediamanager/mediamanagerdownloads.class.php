<?php
class MediamanagerDownloads extends xPDOSimpleObject {}