<?php
require_once (dirname(dirname(__FILE__)) . '/mediamanagerfilestags.class.php');
class MediamanagerFilesTags_mysql extends MediamanagerFilesTags {}