<?php
require_once (dirname(dirname(__FILE__)) . '/mediamanagerfiles.class.php');
class MediamanagerFiles_mysql extends MediamanagerFiles {}