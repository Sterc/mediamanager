<?php
class MediamanagerFilesMeta extends xPDOSimpleObject {}