<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.17
Author: Sterc <modx@sterc.nl>

Media Manager for MODX.
',
    'changelog' => 'Media Manager 0.1.17-pl
=======================
- #20 Fix wrong mediasource shown if default_media_source not set

Media Manager 0.1.16-pl
=======================
- #6 Prevent menu permissions being overwritten
- #19 Fix file choose list mode
- #21 Fix aspect ratio for thumbnails in overview and modal
- #24 Fix thumbnail for input tv
- #27 Fix pagination/infinite scroll in modal
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '50f989441089cb21b91e93cecdade85f',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/92911623738b201c1a5a4413907df583.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7c97298fa6d12829052d6130e509d84',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/74a1207a69788a6fbf0547f4c8294e7d.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7cdb812031bab761d4ae27feed8f40d',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/0ff3aae0332e5b2193398009cb8068a9.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f8fc786da0ccff212eef777b851f349',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/a5436cda68768f62f68aaad46a2cf3f3.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '90ddead735db7f1b6912b91192a776b1',
      'native_key' => NULL,
      'filename' => 'modCategory/4194c1a2cee8d4d5a8eb834a67df0fde.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);