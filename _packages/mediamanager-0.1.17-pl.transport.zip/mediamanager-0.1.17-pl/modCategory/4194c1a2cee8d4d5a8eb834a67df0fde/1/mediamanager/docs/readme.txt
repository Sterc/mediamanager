--------------------
Extra: Media Manager
--------------------
Version: 0.1.17
Author: Sterc <modx@sterc.nl>

Media Manager for MODX.
