<?php
require_once (dirname(dirname(__FILE__)) . '/mediamanagerfileslicense.class.php');

class MediamanagerFilesLicense_mysql extends MediamanagerFilesLicense {}