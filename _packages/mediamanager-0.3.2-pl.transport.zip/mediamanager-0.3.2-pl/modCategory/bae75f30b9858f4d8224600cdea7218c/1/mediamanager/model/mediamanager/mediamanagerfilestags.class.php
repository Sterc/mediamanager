<?php
class MediamanagerFilesTags extends xPDOSimpleObject {}