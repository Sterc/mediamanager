<?php
class MediamanagerFilesLicense extends xPDOSimpleObject {}
