<?php
require_once (dirname(dirname(__FILE__)) . '/mediamanagerfilescontent.class.php');
class MediamanagerFilesContent_mysql extends MediamanagerFilesContent {}