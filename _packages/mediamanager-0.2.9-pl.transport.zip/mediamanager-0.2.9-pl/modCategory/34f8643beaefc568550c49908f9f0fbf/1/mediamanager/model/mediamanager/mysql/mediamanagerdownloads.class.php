<?php
require_once (dirname(dirname(__FILE__)) . '/mediamanagerdownloads.class.php');
class MediamanagerDownloads_mysql extends MediamanagerDownloads {}