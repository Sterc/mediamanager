<?php
class MediamanagerTags extends xPDOSimpleObject {}