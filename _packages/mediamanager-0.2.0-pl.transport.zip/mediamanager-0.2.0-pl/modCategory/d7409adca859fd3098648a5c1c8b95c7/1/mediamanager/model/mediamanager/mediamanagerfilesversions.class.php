<?php
class MediamanagerFilesVersions extends xPDOSimpleObject {}