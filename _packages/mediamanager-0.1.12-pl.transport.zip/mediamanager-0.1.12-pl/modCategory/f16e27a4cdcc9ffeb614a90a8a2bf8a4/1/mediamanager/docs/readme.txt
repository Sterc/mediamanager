--------------------
Extra: Media Manager
--------------------
Version: 0.1.12
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
