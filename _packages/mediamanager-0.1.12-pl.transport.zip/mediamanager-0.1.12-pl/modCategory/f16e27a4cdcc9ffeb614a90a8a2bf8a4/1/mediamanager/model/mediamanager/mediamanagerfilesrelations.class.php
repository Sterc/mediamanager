<?php
class MediamanagerFilesRelations extends xPDOSimpleObject {}