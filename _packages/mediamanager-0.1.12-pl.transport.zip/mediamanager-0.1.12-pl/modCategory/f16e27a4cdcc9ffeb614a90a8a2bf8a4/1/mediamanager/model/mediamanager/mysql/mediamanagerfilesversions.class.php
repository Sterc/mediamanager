<?php
require_once (dirname(dirname(__FILE__)) . '/mediamanagerfilesversions.class.php');
class MediamanagerFilesVersions_mysql extends MediamanagerFilesVersions {}