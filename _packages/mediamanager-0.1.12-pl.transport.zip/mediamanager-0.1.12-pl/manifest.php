<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.12
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6515d0ae8ed37777fc9ad42775b11be0',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/db15e11617706dfcfc46172e9519589a.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '140f7862dbca36ff651d983d2780b56d',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/0ad3bb649658639f9b6f6b75eef29927.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49d6405cadc3d88f2de626011eb01e18',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/2cb8325e09e7442f69a63b5fbfde5e9d.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f77fd04b9fab67500053e323d3aefcd1',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/9babfb58d480b47a42e2b167816d97fd.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '78745e586c60bdb7d68e39436476eee3',
      'native_key' => NULL,
      'filename' => 'modCategory/f16e27a4cdcc9ffeb614a90a8a2bf8a4.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd2649951f4808d92f1d283267fc5bac6',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/c71c88ef100519e679677d7ff85689fd.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b57337b791a46539add17f7523909dda',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/2c4439ae5ed4ee000cef78a859102bc2.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cf5586314ec39a924cfe3bb44d8e3602',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/8f5c7c040caf6d6c129b54a5c05522af.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);