<?php
require_once (dirname(dirname(__FILE__)) . '/mediamanagerfilesmeta.class.php');
class MediamanagerFilesMeta_mysql extends MediamanagerFilesMeta {}