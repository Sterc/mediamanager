<?php
require_once (dirname(dirname(__FILE__)) . '/mediamanagercategoriesexcludes.class.php');
class MediamanagerCategoriesExcludes_mysql extends MediamanagerCategoriesExcludes {}