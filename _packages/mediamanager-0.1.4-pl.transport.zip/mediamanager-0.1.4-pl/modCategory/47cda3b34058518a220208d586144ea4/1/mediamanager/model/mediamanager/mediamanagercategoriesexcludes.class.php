<?php
class MediamanagerCategoriesExcludes extends xPDOSimpleObject {}