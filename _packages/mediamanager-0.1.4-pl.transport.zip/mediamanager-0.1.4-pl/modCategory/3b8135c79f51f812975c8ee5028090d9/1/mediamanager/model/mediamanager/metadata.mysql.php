<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'MediamanagerCategories',
    1 => 'MediamanagerTags',
    2 => 'MediamanagerFiles',
    3 => 'MediamanagerDownloads',
    4 => 'MediamanagerCategoriesExcludes',
    5 => 'MediamanagerFilesCategories',
    6 => 'MediamanagerFilesTags',
    7 => 'MediamanagerFilesContent',
    8 => 'MediamanagerFilesRelations',
    9 => 'MediamanagerFilesVersions',
    10 => 'MediamanagerFilesMeta',
  ),
);