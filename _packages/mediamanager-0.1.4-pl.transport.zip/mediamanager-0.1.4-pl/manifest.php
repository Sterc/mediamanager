<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '47d34df1e003d7cd38e6637aff00fc7c',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/d84fe73d2e2ae79823be27f459636bd2.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69dc4f3112ff57089cd8a9b10129d39b',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/8be2bfa700d147b7c3bd0179a3d2e269.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6b4c0f2fe5d6babb0f169766bc96016',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/aa590ff74f273001550a1c945ef92689.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3075596b80427a696256a2b3d872d3d',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/a5a0b8912f10a4f49b4cfc017cb134a3.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7ea0c62d4fca5048a6a589ff67006fa7',
      'native_key' => NULL,
      'filename' => 'modCategory/2addc496fee4aa9e1e184481c29f717b.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e65a2040147677ea842a29ff98b3e133',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/12fe1f1717be9e1cd45943244aac4dbd.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0db23e9876dab24e5639a37f01e0cd5b',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/8825bceb6778439e0219c5b6cb262f32.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8f950c751a268be2cf4f05b31605db12',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/77fe8d6aa4b6a6755a887b09ce9b6977.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);