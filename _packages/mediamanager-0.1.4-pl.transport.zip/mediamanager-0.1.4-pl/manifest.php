<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a934ee1ce1d9d5448d90972261d0ae65',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/2ca5467e487c3a5e52bd786284d0eece.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f7cbb54a44a8d904a6860902c9bf690',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/c95c4408ae49ed8c51d1045db0814691.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8aea627fe56037a80996c4bb6ee5d36',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/0938457d860e4ed4cebce4e2b1caf4b1.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d0c43dff684f42ae2e9ef4b0164ad29',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/0e137caa835fb23ff8b4120c2bfb266f.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '524eff88728fa3dd21811bdd8e9ae13a',
      'native_key' => NULL,
      'filename' => 'modCategory/47cda3b34058518a220208d586144ea4.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ec2f2f4277e04a565681694f6ef85c5e',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/552790eea1869728e2356f31d1d06a3b.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e56f38a2ad45223be62784e3a9768304',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/007144c189ed26eb121b8fd343bc1f13.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '27708f99b4a268e10f9b8dc07ca3b22c',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/39fd317a78d94a52810bcd0b9936c0f9.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);