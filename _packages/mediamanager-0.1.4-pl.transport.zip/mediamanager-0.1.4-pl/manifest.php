<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '632e0522b99096300cd26e661ea99014',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/f97cedbcad231297bd0d296009e23a41.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8160e1ee3700473f40c6a57eafad2cb',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/2176ae4e924aa2a300ef3c8194ff3d46.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4412b8c298086ebc9ffab3f73cc15853',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/bb0f2fcf5e08db52a22dbe0d09db0496.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5731a6cba29591578dc08c736243969',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/3dd81bc7a0ed4b397f60ac9beb86e0f7.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a750580628f7c5dc73d144a3dc2a8828',
      'native_key' => NULL,
      'filename' => 'modCategory/3b8135c79f51f812975c8ee5028090d9.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f97bb77f6367de68c806e5b40028ae10',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/67e37c2cc6e726c5bc862e0bc36b7e6f.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '241e74d987f3ef2c450d2cebe8dc332e',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/58f9a07c58d22374f5111ec41b934a31.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6be4aed0eb0682c4b43a95b737280d6d',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/a61394209a3f06df04dcff47ee816696.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);