<?php
/**
 * @package mediamanager
 */
class MediamanagerFilesLicenseFile extends xPDOSimpleObject {}
?>