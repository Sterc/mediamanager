<?php
require_once (dirname(dirname(__FILE__)) . '/mediamanagercategories.class.php');
class MediamanagerCategories_mysql extends MediamanagerCategories {}