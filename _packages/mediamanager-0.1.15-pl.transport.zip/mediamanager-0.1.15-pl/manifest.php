<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.13
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9810ed6c390c385a0146ddd7c12180b8',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/c6de929695fd61b03b0af5048e3b02cc.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e11544b37d942b1c8bd284fbff233e4',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/6f6ccbf45ecf2e18e8b43d6ad4953359.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3101760afa5e2437972d4278a901d1f1',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/debb64a15560726c352d118e084dc117.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef9da2c57befd19e264d7b4b33dcb9b4',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/ebd62fcba57da0c16c94f06dba86c61b.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0296721477558532f5bbdead637ae249',
      'native_key' => NULL,
      'filename' => 'modCategory/29e087a3da05a794cbde075be9976188.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '24d1e84f2268382d54185e9556a73945',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/784e19822c01fc4600168b6fdfb8695d.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1c29c83e5f44bdb38b34d5a6a5cdef64',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/7dd410d9d4437cb5cf4665fb8f09c863.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd61283bc136c994f1acf6dbd17bf527f',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/a0e24a0545f164defa09f49d962169ae.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);