--------------------
Extra: Media Manager
--------------------
Version: 0.1.5
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
