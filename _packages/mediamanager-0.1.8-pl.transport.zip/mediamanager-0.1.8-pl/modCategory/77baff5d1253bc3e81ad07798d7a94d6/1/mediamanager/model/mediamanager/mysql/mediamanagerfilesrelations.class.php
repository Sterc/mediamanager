<?php
require_once (dirname(dirname(__FILE__)) . '/mediamanagerfilesrelations.class.php');
class MediamanagerFilesRelations_mysql extends MediamanagerFilesRelations {}