<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.5
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'afff7b1ea5adcbb16bdb0d14191f2907',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/5756b2fd546f6c7ecf7c814eee86e552.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cda4cfa2c9f65ab8216486f7bb5057ba',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/5044f30438636d49d5025c36d722210f.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5eb31e1bfd993a0b242733f744eb5225',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/eea426ab5678f69c99fae2a611fb11db.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '034c60ef8c771b7c877dcb958d8c36eb',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/ce548cc408154a1f0d9d59279f419e89.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7ee3fcf77befa835511377d48276d028',
      'native_key' => NULL,
      'filename' => 'modCategory/77baff5d1253bc3e81ad07798d7a94d6.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fcb0d726f373c2e30f3c071316503a56',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/42c2d334749032efc8209f22a41d6424.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '631c22081dc5b4bf45e46d2e0808a72f',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/413e7c51ed3c5b4575bcf2af83c9ed91.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8be3d68a0fc555f19078acb35b3ecaec',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/df2ae039089eb5e76d39517a6681c516.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);