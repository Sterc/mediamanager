<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.5
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9b4694790175dc704d78bd9a45300685',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/dc7f8ceddc8352f55b54541460749b21.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecbd288c033a28394af70c447f08d4e7',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/bb1dd07b244cf8b60e845587e2834833.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20cac7178f0029d9e34aa11199f3fbeb',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/87438a216db42266a95f747376216d2e.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff6e70d64cd9eff6f0f7cc00676bbfa4',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/ed82323de5b45619a89a1ba8528badd1.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2bddd4db8c5d6b22a6a6c21b9db8f0f4',
      'native_key' => NULL,
      'filename' => 'modCategory/ab6da78625f6ec9eb728cb56e607dc70.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cb91bd7b221fcad784a5ee5d5b0da54e',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/299c1a6222bfff6d2319a147e98afcc7.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '85d1880551802dcbb8432b8211f8245e',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/bbea6b37b782b73292f8d2f66069bea1.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '74f2e2d6c3fb0eaa504f885cf15c55e5',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/6634aa892f1312d8e2ea729163706c11.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);