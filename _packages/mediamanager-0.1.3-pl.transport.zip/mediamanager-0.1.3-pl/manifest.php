<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5d47b36aa803940d5a75084dccde7917',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/ed72486b07dddab6dd3e36b8ee21ab13.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9314aac71c31a433fc63ffcfd3bb07d1',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/42c300944aac4b0db634b21150f8d589.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29f87a5c1726b8ffa6b2f97b01df026d',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/4b41004e9dc52a680e563e579605975c.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '768ea9d6d4462f5f46f1d8bec5b48841',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/65305073290b4cb0eaefecd2c2e9d06d.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3a25eb125d95490baeb5b8b130f396fc',
      'native_key' => NULL,
      'filename' => 'modCategory/05c7c69dffbb7106a77e9bbbd301f578.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '21987dc53e60d76b11da960657f274cb',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/7ad996ff671e85f9d89306fa8da74bac.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f2ad05d234363ac25ac33c9638fdc849',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/bd76ec1bef700fef5eb9b842cc773c83.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4008bd1c7aa3ba0e1103696a51615f67',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/39a566c4072b1d2a357ff83667e5b846.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);