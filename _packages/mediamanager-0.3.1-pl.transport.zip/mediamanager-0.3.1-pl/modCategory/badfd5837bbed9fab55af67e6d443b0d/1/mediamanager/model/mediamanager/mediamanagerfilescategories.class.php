<?php
class MediamanagerFilesCategories extends xPDOSimpleObject {}