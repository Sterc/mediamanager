<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.5
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e3e14adb5d45a8ee7dece579660f6198',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/10257444a76c7fbeab6a5beb071a05f5.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae9e6190616d54cdb21c6a6ee1947a42',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/46833d24022ec95346b4a41d91d0c442.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01657809d5daed439b1e2251078b2f74',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/e4c8033ae897c1a1fdcbc66f5b4f4bc0.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ffa6527c9f5dc2b7fa159e7b53e6bd3',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/f12b367568a20506b10eb9d5ce58ff76.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9f8ebb29e30a0fe1cd9ab5ea67e9bb05',
      'native_key' => NULL,
      'filename' => 'modCategory/feae2ab9ee9b698a286333203ae3600b.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ac9ec4cde2619b12c070499d61de764c',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/7afd65020b391f08c2d4cb0066e2ca15.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '68f6ec6ae28939569805a6f0e250811a',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/0782b6c2b62c422eab1dda7e484fe646.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c93169a2641f44481f7096e6feaf94b9',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/b3dcd723af6c9ff81e89ee003f7cdddc.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);