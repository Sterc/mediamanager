<?php
require_once (dirname(dirname(__FILE__)) . '/mediamanagertags.class.php');
class MediamanagerTags_mysql extends MediamanagerTags {}