<?php
class MediamanagerFiles extends xPDOSimpleObject {}