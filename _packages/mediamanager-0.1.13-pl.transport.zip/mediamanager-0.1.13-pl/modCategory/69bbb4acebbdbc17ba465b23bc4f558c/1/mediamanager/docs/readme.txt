--------------------
Extra: Media Manager
--------------------
Version: 0.1.13
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
