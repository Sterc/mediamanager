<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.13
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9060d4edb8d5ff5db550206ebc37ea8c',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/fc4e74ee47f9cbcf7aa1ec85a08295fd.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0eadc6de99bfae1a0d38131f79b4bf7a',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/6ebdc7398b7d6bab20bf2a9b520800e3.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f27a65dcd1daf84fa22602ca6b96836',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/0cf76a50f0b18694f4cb4cd1eb67107c.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88661063159f0f2d514ebb9537396c85',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/51dde4897a6072652fca2a4841a1d8e5.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'eb817a6e87bbda92eb12fcad64476a9d',
      'native_key' => NULL,
      'filename' => 'modCategory/69bbb4acebbdbc17ba465b23bc4f558c.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6b0bfc45a3ebfaa54c9e1cd4a03d0336',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/27648967278b96c53be477586b92a8dd.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '870d882fd1cc93bcf90e0c41a8115864',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/b45ca59628fbccadb03a3f1db877c8c0.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bd5bf70fdb6125677774e27234bb065d',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/cb04c2988d4b2cb782d6daa7d42fe178.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);