<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.13
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6dec6f86d1800111d1bb4bc8c1a865d3',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/d2cb45c3e4f60bb1f96c9e4fc42e7712.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb9feeaca7c932a4fff84b6ca625a450',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/5fc6b40336a7d8a421a02009ade2a79e.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea9fe2c240580c17c0796f5214dfe873',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/1ee484078169a461c4c2f21aafac34cb.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e340d9846cb16dcfedc19f994a032266',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/b928840daf06b438cec6d5cac05bc448.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '73e9ccc05d0778a2340962f146eb278f',
      'native_key' => NULL,
      'filename' => 'modCategory/543f2954d39f2c006aabe25c29d47d01.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '08f51c82332a6cc2b460129972f44df4',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/d4c3f8fc52447ecf7aa347a257c94ca1.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '246faf2dc523425db38f0fddacd342a2',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/0c51a5dd36105edc17facf6cb11eb85a.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1e66e71d3ae8c6f515c75bd83b8c09e8',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/8813254788e44357cca57e0d96315af7.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);