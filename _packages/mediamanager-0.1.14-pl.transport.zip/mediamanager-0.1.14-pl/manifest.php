<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.13
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '67bc9e0224c90a7accc215d53f525c25',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/c72a0133eea6604155a75015fb281430.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13d465f733822b132091375667d7a288',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/ea38eafc4678cebfebf0a6e4728cfefd.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '987092059c05f2c2808a78517a641c30',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/00e5db8f0281d94ad004e64dbbea7031.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9de647e193818555377e10d6644a366',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/b912e30b18992471aca58a136af83c5c.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '87189f52ef2adb25c19bb8a5e96b0268',
      'native_key' => NULL,
      'filename' => 'modCategory/111690469dae5369c07ef913340e6d13.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '36871fcfc2545463972c4b8f7349d604',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/c1616950b6fdc3bb62c33b2c5b6eb4f6.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9198e02ea1eece4db38db8ca176fba43',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/ca5cd985cb5bd4d32fefb2760ae6d91c.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6491bd2100b7df2473a98ade6151f2e3',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/8af3a2207ecb05e572f975c51638ae1e.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);