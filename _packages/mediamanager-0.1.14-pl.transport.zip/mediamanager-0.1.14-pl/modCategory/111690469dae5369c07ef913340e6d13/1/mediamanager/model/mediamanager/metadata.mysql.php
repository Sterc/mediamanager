<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'MediamanagerCategories',
    1 => 'MediamanagerTags',
    2 => 'MediamanagerFiles',
    3 => 'MediamanagerDownloads',
    4 => 'MediamanagerFilesCategories',
    5 => 'MediamanagerFilesTags',
    6 => 'MediamanagerFilesContent',
    7 => 'MediamanagerFilesRelations',
    8 => 'MediamanagerFilesVersions',
    9 => 'MediamanagerFilesMeta',
  ),
);