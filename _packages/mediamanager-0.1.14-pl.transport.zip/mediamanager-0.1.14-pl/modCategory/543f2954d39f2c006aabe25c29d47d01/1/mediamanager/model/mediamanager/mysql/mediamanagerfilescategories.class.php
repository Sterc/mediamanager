<?php
require_once (dirname(dirname(__FILE__)) . '/mediamanagerfilescategories.class.php');
class MediamanagerFilesCategories_mysql extends MediamanagerFilesCategories {}