--------------------
Extra: Media Manager
--------------------
Version: 0.1.16
Author: Sterc <modx@sterc.nl>

Media Manager for MODX.
