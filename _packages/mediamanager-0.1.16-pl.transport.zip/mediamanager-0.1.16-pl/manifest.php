<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.16
Author: Sterc <modx@sterc.nl>

Media Manager for MODX.
',
    'changelog' => 'Media Manager 0.1.16-pl
=======================
- #6 Prevent menu permissions being overwritten
- #19 Fix file choose list mode
- #21 Fix aspect ratio for thumbnails in overview and modal
- #24 Fix thumbnail for input tv
- #27 Fix pagination/infinite scroll in modal
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e4f839e8435fd4a4670a163151ce7e87',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/3eba9fed97d2c89970a99f6ad80418fb.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89d2c30f05d1470a26c6c96463eaad7c',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/4ce1ff1eb3ffd9c8431b7feac0df1a33.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69571aadcee3548ed78bb5f027a3acb8',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/584b9f7c449c1ab86bbdb1e0d1169354.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a706e3364ed357a75297f613172914f3',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/3b5caeedab00516bc06cd3afa844c67a.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '93fef7cc8fc9c6e6e033cff5c3554212',
      'native_key' => NULL,
      'filename' => 'modCategory/45bdd961a98fd1f2dc92438e5ecaff66.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);