<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.5
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '556ba2ef58a1397baa33ba8fbd3c7147',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/c8e5b7d898bdd20467fbcfc617a7401d.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b775825f141bd3e526044cdbfd9fbf4',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/daf865687d33aba8a59c3eb6f16d22da.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e6c3fe851653892689873b7d71e120e',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/a6111fc81741272633cfed53f0334ea9.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d033bf8a39834a0f975ee732df3ea83',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/4fc34b8223c45dd5acec1beca597e855.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'cca8e777a605c36ce8ed8316617cbfe9',
      'native_key' => NULL,
      'filename' => 'modCategory/7ee1c045dadccb4c334b44e764f7cb7c.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '840810f91fb1125ec7ce4c9bf86f46d1',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/237203c9ebea23d853635e9dc836c04a.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c1f25aaab10c01ea55a679b476b561b5',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/408e7662ebbfd379e6fd0db65906c70d.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '083f52ea74d0020407535d48b4b2d203',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/e7b77cee16abf04e5688d72361f5d8af.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);