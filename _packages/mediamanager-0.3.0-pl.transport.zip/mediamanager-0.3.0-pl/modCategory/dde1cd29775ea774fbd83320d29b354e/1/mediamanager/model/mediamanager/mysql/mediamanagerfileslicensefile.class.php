<?php
/**
 * @package mediamanager
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/mediamanagerfileslicensefile.class.php');
class MediamanagerFilesLicenseFile_mysql extends MediamanagerFilesLicenseFile {}
?>