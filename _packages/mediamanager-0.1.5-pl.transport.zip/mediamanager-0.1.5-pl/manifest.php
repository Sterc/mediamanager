<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.5
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '19194c4da6008fd7d009a92a543e11fe',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/843cae90938d31cbe3dcbada903db5b9.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1be7f27199c155b040425e2d709bc9f7',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/ee24ae81b42e69aff69e0566dee49580.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1bc361e2a755a2206afb98bad248657',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/1ee02b7e2dc0a78bb55d92533c505031.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e326b15d44fad4e55c350f741830f5f',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/99a631cebeca17a95c017bccc5c60a29.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '83c532ec7ce7153999ef6201bc09fb6f',
      'native_key' => NULL,
      'filename' => 'modCategory/723d1c63c1ac6811a20acad8f1cf719e.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '786589eafb801f8d8afbdc6d17558f8e',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/4041629ba8e4e4424fdd7428082af9b2.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3371c9ce6c3ae78c93970bba9d42907f',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/1b814e8396ca91eebb75ec70e242c600.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '99eecaa707f225726774c09e33e611a1',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/fb7151e07b9d28a3bf4b360efbd9f027.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);