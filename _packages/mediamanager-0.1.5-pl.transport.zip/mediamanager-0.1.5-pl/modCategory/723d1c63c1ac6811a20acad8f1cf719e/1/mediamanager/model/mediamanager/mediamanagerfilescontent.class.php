<?php
class MediamanagerFilesContent extends xPDOSimpleObject {}