<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.5
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1aeb40783e3b7b825a6b3caac3a9064f',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/9fbe6be2009beeddde6e6fbb77123acf.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09dbdc46593cf9733c56490f10352c3a',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/557711e1b3884844c9e77b369cec48d0.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a5d6f1ec69de2f8892ce1452eac26c3',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/c7497b87c7e3d86d1c0621f17680584a.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1f992517e175c86e528ca2f6db74044',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/2b2522d9766a076f7d55ed5f5848af50.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '014b5c3c8bf9ca32c33c330a8b9fe6fb',
      'native_key' => NULL,
      'filename' => 'modCategory/86e712f1aae75218449375772eaf3e2c.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e2b643b31e097b782e5ad3a5948c7887',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/f07f93359e967f883702b2b8a39bd75d.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '46b655c6e07dc20a00bbdf8a1bdb3c32',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/eff2fc5761488e3888ec71c25a7455eb.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd8be0a37d807c49935842cd70c5f0fff',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/aee75897d955c6374de4cead58038202.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);