<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.5
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e3f6646dda5d77ba0494e93d4db33124',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/6f623b2631c327f09fc18ef425234fc5.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9059c24f6bbd1f82003df869858591b4',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/24e69b4288f8592674e0134db0433238.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27859edae8e9700c39a0045e74af06a9',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/108b838e73a932105f62285768952d93.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07389c2f222ef057c2108ff9718b6df1',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/e6101c2385182a665cdcbf5da951b84e.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6abc8f2086fcbc83a710774d4533f994',
      'native_key' => NULL,
      'filename' => 'modCategory/909c225ffeca68e9ff8f05181eb1da16.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '611c67ba79a01b747fde1c6532e897c8',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/6046ca6a18e12dfe752b3547ae4f64e5.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7cab5e98c17eb9eac71a127214e0831a',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/5fa58cdfbccf2346290ba27f0cb62fd2.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1ca8faf80b8340e7c45819968782dbb4',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/a38cbb2d77e7113c6f7608f50cc971b1.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);