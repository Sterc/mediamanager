<?php
class MediamanagerCategories extends xPDOSimpleObject {}