<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: Media Manager
--------------------
Version: 0.1.5
Author: Sterc <modx+mediamanager@sterc.nl>

Media Manager for MODX.
',
    'changelog' => '',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'bf44b1ed4298eb8e10f9ecf0d0fc4630',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/2c60b6510a6cce1feaab61b9e14c27f5.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da7070fe0deab11f8d0f1963ca39f65f',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/14767e58cfbfdf34b5ee41ed6e617ba9.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1194d6bffeb87cc81ef53111370ae498',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/50271b1855249662ecb2f6f3c3ba0ca1.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9059dbcfd5bdf4bc71229fec7a4ea4a',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/d0f90b6db5e732eaaa23412a69f7e07a.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f33698cc936122359065da73fdee89e0',
      'native_key' => NULL,
      'filename' => 'modCategory/dca6d2022c248859ef4f96d56a84fcc7.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd3b1fbc2a023367c304e34ba194bab0c',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/b35cc7ebc1d95c477e18bb561e519ee8.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ef64546659fc0f11a9107fe1ef76e956',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/a0fe41de41d61717e8eab7bcd594e129.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f98566e82daec93b50bbc5f1e79a8103',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/a1e2904b5b4b60942af5a2ce62e65d25.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);